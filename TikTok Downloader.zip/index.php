<?php
require_once __DIR__ . '/app/config.php';
include_once __DIR__ . '/system/' . theme_name . '/header.php';
include_once __DIR__ . '/system/' . theme_name . '/main.php';
include_once __DIR__ . '/system/' . theme_name . '/footer.php';