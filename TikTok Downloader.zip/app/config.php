<?php
const theme_name = 'default';
const website_url = 'http://localhost/tiktok/upload/';
const contact = 'https://www.buymeacoffee.com/storysaver';
const website_name = 'SaveTIK';
const image_header = 'assets/images/logo-header.svg';
const background_image = 'https://wallpaperaccess.com/full/29820.jpg';
const background_style = 'background-image: radial-gradient( circle farthest-corner at 12.3% 19.3%,  rgba(85,88,218,1) 0%, rgba(95,209,249,1) 100.2% ); opacity: 0.9;';
const website_title = 'Tik Tok video Downloader with no water mark';
const website_subtitle = 'Online Video Downloader';
const website_description = 'Download your Tik Tok video/Image by just  url';
const website_keywords = 'Tik Tok video, Download Tik Tok video, Download Tik Tok video';