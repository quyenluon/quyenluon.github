<footer class="bg-dark text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2021 Copyright:
    <a class="text-light" href="<?php echo website_url ?>"><?php echo website_name ?></a>
  </div>
  <!-- Copyright -->
</footer>
<!-- jQuery -->
<script src="assets/js/jquery.min.js"></script>
<!-- Popper JS -->
<script src="assets/js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Theme JS -->
<script src="assets/js/main.min.js"></script>
</body></html>